import 'package:flutter/material.dart';

class AssignedDeliveryScreen extends StatelessWidget {
  const AssignedDeliveryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: Text("This is the Assigned Delivery page")),
    );
  }
}
